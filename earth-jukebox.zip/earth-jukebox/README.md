# The Earth Information Jukebox

Proyecto para NASA Space Apps (The Earth Information Jukebox): sonificación y visualización de la evolución de datos de la Tierra por hemisferio (Norte/Sur).

```
cd backend && pip install -r requirements.txt
export METEOMATICS_USER=tu_usuario METEOMATICS_PASS=tu_clave
uvicorn main:app --reload      # abre http://localhost:8000
```

- Vista general por hemisferio (punto representativo por hemisferio, versión rápida).
- Cada fenómeno usa un timbre de sonido distinto y la tonalidad varía según el valor de la serie temporal.
- Añadir una pista: una entrada nueva en `TRACKS` (backend/main.py) y, opcionalmente, su timbre en `TIMBRES` (frontend/index.html).
- Cuentas gratuitas de Meteomatics limitan parámetros/área: si una pista responde 403, no está en tu plan.
